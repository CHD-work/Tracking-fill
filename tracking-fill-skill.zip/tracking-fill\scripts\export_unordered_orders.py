#!/usr/bin/env python3
import argparse
import json
from copy import copy
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.utils import column_index_from_string


def text(value):
    return "" if value is None else str(value).strip()


def col_index(col):
    return column_index_from_string(col) if isinstance(col, str) else int(col)


def find_sheet(workbook, contains):
    needle = contains.lower()
    matches = [ws for ws in workbook.worksheets if needle in ws.title.lower()]
    if not matches:
        names = [ws.title for ws in workbook.worksheets]
        raise SystemExit(f"No sheet title contains {contains!r}. Available sheets: {names}")
    return matches[0]


def copy_cell_style(src, dst):
    if src.has_style:
        dst.font = copy(src.font)
        dst.fill = copy(src.fill)
        dst.border = copy(src.border)
        dst.alignment = copy(src.alignment)
        dst.number_format = src.number_format
        dst.protection = copy(src.protection)
    if src.hyperlink:
        dst._hyperlink = copy(src.hyperlink)
    if src.comment:
        dst.comment = copy(src.comment)


def display_value(value_ws, row_idx, col_idx, platform_col, formula_left_col, formula_right_col):
    value = value_ws.cell(row_idx, col_idx).value
    if col_idx == platform_col and (value is None or str(value).startswith("=")):
        left = text(value_ws.cell(row_idx, formula_left_col).value)
        right = text(value_ws.cell(row_idx, formula_right_col).value)
        if left and right:
            return f"{left}{right}"
    return value


def parse_args():
    parser = argparse.ArgumentParser(
        description="Export unplaced/unordered rows from a Feishu-downloaded order workbook."
    )
    parser.add_argument("--source", required=True, help="Source .xlsx exported from Feishu.")
    parser.add_argument("--output", required=True, help="Output .xlsx order import workbook.")
    parser.add_argument("--sheet-contains", default="IP Moana", help="Substring of target sheet title.")
    parser.add_argument("--bd-col", default="A", help="Real row marker column; must be non-blank.")
    parser.add_argument("--status-col", default="C", help="Order-arranged status column; blank means unordered.")
    parser.add_argument("--platform-col", default="H", help="Platform order column; must be non-blank.")
    parser.add_argument("--formula-left-col", default="F", help="Left column used to compute platform order if cached formula value is missing.")
    parser.add_argument("--formula-right-col", default="G", help="Right column used to compute platform order if cached formula value is missing.")
    parser.add_argument("--header-row", type=int, default=1, help="Header row to copy into output.")
    parser.add_argument("--no-copy-style", action="store_true", help="Write values only without copying source styles.")
    return parser.parse_args()


def main():
    args = parse_args()
    source = Path(args.source)
    output = Path(args.output)

    bd_col = col_index(args.bd_col)
    status_col = col_index(args.status_col)
    platform_col = col_index(args.platform_col)
    formula_left_col = col_index(args.formula_left_col)
    formula_right_col = col_index(args.formula_right_col)

    style_wb = load_workbook(source)
    value_wb = load_workbook(source, data_only=True)
    style_ws = find_sheet(style_wb, args.sheet_contains)
    value_ws = value_wb.worksheets[style_wb.worksheets.index(style_ws)]

    candidate_rows = []
    for row_idx in range(args.header_row + 1, style_ws.max_row + 1):
        bd = text(display_value(value_ws, row_idx, bd_col, platform_col, formula_left_col, formula_right_col))
        status = text(display_value(value_ws, row_idx, status_col, platform_col, formula_left_col, formula_right_col))
        platform = text(display_value(value_ws, row_idx, platform_col, platform_col, formula_left_col, formula_right_col))
        if bd and not status and platform:
            candidate_rows.append(row_idx)

    out_wb = Workbook()
    out_ws = out_wb.active
    out_ws.title = "订单导入表"

    rows_to_copy = [args.header_row] + candidate_rows
    max_col = style_ws.max_column
    for out_row_idx, src_row_idx in enumerate(rows_to_copy, 1):
        for col_idx in range(1, max_col + 1):
            src_cell = style_ws.cell(src_row_idx, col_idx)
            out_cell = out_ws.cell(out_row_idx, col_idx)
            out_cell.value = display_value(value_ws, src_row_idx, col_idx, platform_col, formula_left_col, formula_right_col)
            if not args.no_copy_style:
                copy_cell_style(src_cell, out_cell)
        out_ws.row_dimensions[out_row_idx].height = style_ws.row_dimensions[src_row_idx].height

    if not args.no_copy_style:
        for col_idx in range(1, max_col + 1):
            letter = style_ws.cell(args.header_row, col_idx).column_letter
            out_ws.column_dimensions[letter].width = style_ws.column_dimensions[letter].width
            out_ws.column_dimensions[letter].hidden = style_ws.column_dimensions[letter].hidden

    out_ws.freeze_panes = "A2"
    out_ws.auto_filter.ref = out_ws.dimensions
    output.parent.mkdir(parents=True, exist_ok=True)
    out_wb.save(output)

    check_wb = load_workbook(output, data_only=False)
    check_ws = check_wb.active
    formula_rows = []
    bad_rows = []
    for row_idx in range(2, check_ws.max_row + 1):
        platform_value = check_ws.cell(row_idx, platform_col).value
        if isinstance(platform_value, str) and platform_value.startswith("="):
            formula_rows.append(row_idx)
        if not text(check_ws.cell(row_idx, bd_col).value) or text(check_ws.cell(row_idx, status_col).value):
            bad_rows.append(row_idx)

    unique_orders = sorted({
        text(check_ws.cell(row_idx, platform_col).value)
        for row_idx in range(2, check_ws.max_row + 1)
        if text(check_ws.cell(row_idx, platform_col).value)
    })

    print(json.dumps({
        "source": str(source),
        "sheet": style_ws.title,
        "output": str(output),
        "candidate_rows": len(candidate_rows),
        "unique_orders": len(unique_orders),
        "source_rows": candidate_rows,
        "formula_rows_in_platform_col": formula_rows,
        "bad_rows": bad_rows,
        "first_orders": unique_orders[:10],
        "last_orders": unique_orders[-10:],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
